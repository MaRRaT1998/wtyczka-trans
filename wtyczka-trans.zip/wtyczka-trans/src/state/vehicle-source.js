import { SELECTORS } from "../content/selectors.js";

export function getVehicleLocationFromPage() {
  const el = document.querySelector(SELECTORS.vehicleCurrentPlace);
  if (!el) return null;
  return normalizePlace(el.innerText);
}

function normalizePlace(text) {
  if (!text) return null;
  return text.replace(/\s+/g, " ").trim();
}