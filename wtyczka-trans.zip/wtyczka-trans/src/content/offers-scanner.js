import { SELECTORS } from "./selectors.js";

export function getAllOffers() {
  return Array.from(document.querySelectorAll(SELECTORS.offerRow));
}

export function extractOfferPlaces(offerEl) {
  const loadingEl = offerEl.querySelector(SELECTORS.loadingPlace);
  const unloadingEl = offerEl.querySelector(SELECTORS.unloadingPlace);

  const loading = loadingEl ? normalizePlace(loadingEl.innerText) : null;
  const unloading = unloadingEl ? normalizePlace(unloadingEl.innerText) : null;

  return { loading, unloading };
}

export function hasMarketplaceTag(offerEl) {
  const tags = offerEl.querySelectorAll(SELECTORS.offerTags);
  return Array.from(tags).some((t) =>
    t.innerText.toLowerCase().includes("giełda")
  );
}

function normalizePlace(text) {
  if (!text) return null;
  return text.replace(/\s+/g, " ").trim();
}