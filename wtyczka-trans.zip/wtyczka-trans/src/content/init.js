import { initMapButtons } from "./map-button.js";
import { initPanel } from "../ui/panel.js";
import { initFloatingToggle } from "../ui/floating-toggle.js";

function start() {
  initPanel();
  initFloatingToggle();
  initMapButtons();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", start);
} else {
  start();
}