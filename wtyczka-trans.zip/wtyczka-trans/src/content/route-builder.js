import { getVehicleLocationFromPage } from "../state/vehicle-source.js";
import { extractOfferPlaces } from "./offers-scanner.js";

export function buildRouteUrl(offerEl) {
  const vehiclePlace = getVehicleLocationFromPage();
  const { loading, unloading } = extractOfferPlaces(offerEl);

  const parts = [];
  if (vehiclePlace) parts.push(vehiclePlace);
  if (loading) parts.push(loading);
  if (unloading) parts.push(unloading);

  if (parts.length < 2) return null;

  const encoded = parts.map((p) => encodeURIComponent(p));
  return `https://www.google.com/maps/dir/${encoded.join("/")}`;
}