export const SELECTORS = {
  offerRow: '[data-ctx="row"][data-freightid]',
  loadingPlace: '[data-ctx="loading-place-cell"] [data-ctx="place"] [data-ctx="ellipsis"]',
  unloadingPlace: '[data-ctx="unloading-place-cell"] [data-ctx="place"] [data-ctx="ellipsis"]',
  offerTags: '[data-ctx="loading-place-cell-with-tags"] [data-ctx="offer-tag"]',
  vehicleCurrentPlace: '[data-ctx="loading-place-chips"] [data-ctx="place"] [data-ctx="ellipsis"]'
};