import { getAllOffers } from "./offers-scanner.js";
import { buildRouteUrl } from "./route-builder.js";

const BUTTON_CLASS = "trans-eu-map-btn";

export function initMapButtons() {
  attachToExistingOffers();
  observeForNewOffers();
}

function attachToExistingOffers() {
  const offers = getAllOffers();
  offers.forEach((offerEl) => attachButton(offerEl));
}

function attachButton(offerEl) {
  if (offerEl.querySelector("." + BUTTON_CLASS)) return;

  const actionsContainer =
    offerEl.querySelector('[data-ctx="actions"]') || offerEl;

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = BUTTON_CLASS;
  btn.title = "Pokaż trasę w Google Maps";
  btn.innerHTML = "🗺";

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const url = buildRouteUrl(offerEl);
    if (!url) return;
    window.open(url, "_blank");
  });

  actionsContainer.prepend(btn);
}

function observeForNewOffers() {
  const listRoot = document.body;
  if (!listRoot) return;
  const obs = new MutationObserver((mutations) => {
    mutations.forEach((m) => {
      m.addedNodes.forEach((node) => {
        if (!(node instanceof HTMLElement)) return;
        if (node.matches && node.matches('[data-ctx="row"][data-freightid]')) {
          attachButton(node);
        }
        const offers = node.querySelectorAll
          ? node.querySelectorAll('[data-ctx="row"][data-freightid]')
          : [];
        offers.forEach((el) => attachButton(el));
      });
    });
  });
  obs.observe(listRoot, { childList: true, subtree: true });
}