export function initFloatingToggle() {
  if (document.getElementById("trans-eu-toggle")) return;

  const btn = document.createElement("button");
  btn.id = "trans-eu-toggle";
  btn.textContent = "TH";
  Object.assign(btn.style, {
    position: "fixed",
    right: "16px",
    bottom: "16px",
    width: "44px",
    height: "44px",
    borderRadius: "12px",
    border: "1px solid #d0d7de",
    background: "#fff",
    zIndex: "999999",
    cursor: "pointer",
    fontWeight: "600",
  });

  btn.addEventListener("click", () => {
    const panel = document.getElementById("trans-eu-panel");
    if (!panel) return;
    const isHidden = panel.style.display === "none";
    panel.style.display = isHidden ? "block" : "none";
  });

  document.body.appendChild(btn);
}