export function initPanel() {
  if (document.getElementById("trans-eu-panel")) return;

  const wrapper = document.createElement("div");
  wrapper.id = "trans-eu-panel";
  wrapper.innerHTML = `
    <div class="trans-eu-panel-header">
      <button data-tab="vehicles" class="active">Pojazdy</button>
      <button data-tab="costs">Kalkulator kosztów</button>
      <button data-tab="planner">Planer ładunków</button>
      <button data-tab="settings">Ustawienia</button>
    </div>
    <div class="trans-eu-panel-body">
      <div data-view="vehicles">Lista pojazdów (placeholder)</div>
      <div data-view="costs" style="display:none;">Kalkulator (placeholder)</div>
      <div data-view="planner" style="display:none;">Planer 3D (placeholder)</div>
      <div data-view="settings" style="display:none;">Ustawienia (placeholder)</div>
    </div>
  `;
  document.body.appendChild(wrapper);

  const buttons = wrapper.querySelectorAll(".trans-eu-panel-header button");
  const views = wrapper.querySelectorAll(".trans-eu-panel-body [data-view]");

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.getAttribute("data-tab");
      buttons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      views.forEach((v) => {
        v.style.display = v.getAttribute("data-view") === tab ? "block" : "none";
      });
    });
  });
}